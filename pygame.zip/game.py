#!/usr/bin/env python
#coding:utf-8

player_image_filename = 'paopao.png'
background_image_filename = 'beij.jpeg'
paopao1_image_filename = 'paopao1.png'
paopao2_image_filename = 'paopao2.png'
paopao3_image_filename = 'paopao3.png'



import pygame
from pygame.locals import *
from sys import exit
from random import randint
from gameobjects.vector2 import Vector2
from math import *


pygame.init()


screen = pygame.display.set_mode((640, 480),0,32)

screen_width, screen_height = 640, 480
pygame.display.set_caption("ppzb")

background = pygame.image.load(background_image_filename).convert()
player = pygame.image.load(player_image_filename).convert_alpha()
paopao1 = pygame.image.load(paopao1_image_filename).convert_alpha()
paopao2 = pygame.image.load(paopao2_image_filename).convert_alpha()
paopao3 = pygame.image.load(paopao3_image_filename).convert_alpha()

player_width = player.get_width() 
player_height = player.get_height() 

font1 = pygame.font.Font(None,24)
font2 = pygame.font.Font(None,50)


#x, y = screen_width/2 - player_width/2, screen_height-player_height
#move_a, move_d, move_w, move_s = 0, 0, 0, 0 
rand_bubble = (240, 600, 410)
number = 0
grade_point = 0
k = 1


clock = pygame.time.Clock()
time_z = []

pygame.mouse.set_visible(False)
pygame.event.set_grab(True)

player_pos = Vector2(240,120)
player_speed = 7
player_rotation = 0
player_rotation_speed = 6

timing = 0

COUNT = pygame.USEREVENT + 1
pygame.time.set_timer(COUNT, 1000)



while True: 
    for event in pygame.event.get():
        if event.type == QUIT: 
            exit()
        if event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                exit()
        if event.type == COUNT:
            timing += 1

        pressed_keys = pygame.key.get_pressed()
        pressed_mouse = pygame.mouse.get_pressed()

        rotation_direction = 0
        movement_direction = 0
        rotation_direction = pygame.mouse.get_rel()[0]/5.0
        
        if pressed_keys[K_LEFT]:
            rotation_direction += 1
        if pressed_keys[K_RIGHT]:
            rotation_direction -= 1
        if pressed_keys[K_UP] or pressed_mouse[0] :
            movement_direction += 1
        if pressed_keys[K_DOWN] or pressed_mouse[2] :
            movement_direction -= 1

        #纯键盘控制
        '''
        elif event.type == KEYDOWN:
            timing += 1 
            time_passed_seconds = clock.tick()/1000.0
            if event.key == K_a or event.key == K_LEFT: 
                move_a = randint(0,50)
                x -= move_a*time_passed_seconds
            elif event.key == K_d or event.key == K_RIGHT:
                move_d = randint(0,50)
                x += move_d*time_passed_seconds
            elif event.key == K_UP or event.key == K_w:
                move_w = randint(0,50) 
                y -= move_w*time_passed_seconds
            elif event.key == K_DOWN or event.key == K_s:
                move_s = randint(0,50)
                y += move_s*time_passed_seconds
        elif event.type == KEYUP:
            if event.key == K_a or event.key == K_LEFT: 
                move_a = 0
            elif event.key == K_d or event.key == K_RIGHT: 
                move_d = 0 
            elif event.key == K_UP or event.key == K_w:
                move_w = 0 
            elif event.key == K_DOWN or event.key == K_s:
                move_s = 0

        if x > screen_width-player_width/2: 
            x = screen_width-player_width/2 
        elif x < 0-player_width/2: 
            x = 0-player_width/2
        if y > screen_height-player_height/5: 
            y = screen_height-player_height/5
        elif y < 0: 
            y = 0
        '''
       

    screen.blit(background, (0,0))
    
    rotated_player = pygame.transform.rotate(player, player_rotation)
    w,h = rotated_player.get_size()
    player_draw_pos = Vector2(player_pos.x-w/2, player_pos.y - h/2)
    screen.blit(rotated_player, player_draw_pos)
    
    time_passed = clock.tick()
    time_passed_seconds = time_passed/100.0
    print time_passed_seconds
    print timing

    if timing %5 == 0 :
        if k == 1:
            rand_bubble = (randint(20,400), randint(20,640), randint(20,400))
            k -= 1
        else:
            pass
    if timing % 5 != 0 :
        k = 1
            
        #timing += 1

    player_rotation += rotation_direction * player_rotation_speed * time_passed_seconds

    heading_x = sin(player_rotation*pi/180)
    heading_y = cos(player_rotation*pi/180)
    heading = Vector2(heading_x, heading_y)
    heading *= movement_direction

    player_pos += heading * player_speed * time_passed_seconds    
    
    player_rect = pygame.Rect(player.get_rect())
    player_rect.top = player_pos.y
    player_rect.left = player_pos.x
    player_rect.height = player.get_height()
    player_rect.width = player.get_width()
    paopao1_rect = pygame.Rect(paopao1.get_rect())
    paopao1_rect.top = rand_bubble[1]
    paopao1_rect.left = rand_bubble[0]
    paopao1_rect.height = paopao1.get_height()
    paopao1_rect.width = paopao1.get_width()
    #pygame.draw.circle(screen, (255,0,0), (paopao1_rect.centerx, paopao1_rect.centery), 7)
    paopao2_rect = pygame.Rect(paopao2.get_rect()) 
    paopao2_rect.top = rand_bubble[1]
    paopao2_rect.left = rand_bubble[2]
    paopao2_rect.height = paopao2.get_height()
    paopao2_rect.width = paopao2.get_width()
    #pygame.draw.circle(screen, (255,0,0), (paopao2_rect.centerx, paopao2_rect.centery), 7)
    paopao3_rect = pygame.Rect(paopao3.get_rect())
    paopao3_rect.top = rand_bubble[0]
    paopao3_rect.left = rand_bubble[2]
    paopao3_rect.height = paopao3.get_height()
    paopao3_rect.width = paopao3.get_width()
    #pygame.draw.circle(screen, (255,0,0), (paopao3_rect.centerx, paopao3_rect.centery), 7)

    if time_z == [] :
        if paopao1_rect.colliderect(player_rect):
            number += 1
            grade_point += 1
            time_z.append(timing)
        elif paopao2_rect.colliderect(player_rect):
            number += 1
            grade_point += 2
            time_z.append(timing)
        elif paopao3_rect.colliderect(player_rect):
            number += 1
            grade_point += 3
            time_z.append(timing)
        else :
            pass
       
    else :
        if paopao1_rect.colliderect(player_rect) or paopao2_rect.colliderect(player_rect) or paopao3_rect.colliderect(player_rect):
            pass
        else :
            time_z = []


    screen.blit(paopao1, (rand_bubble[0], rand_bubble[1]))
    screen.blit(paopao2, (rand_bubble[2], rand_bubble[1]))
    screen.blit(paopao3, (rand_bubble[2], rand_bubble[0]))

    if number == 3:
        #if grade_point == 3 :
            
        final_text = font2.render("workout", True, (255,0,0))
        final_text_rect = final_text.get_rect()
        final_text_rect.centerx = screen.get_rect().centerx
        final_text_rect.centery = screen.get_rect().centery
        screen.blit(final_text, final_text_rect)

    first_text = font1.render("Use the mouse or left or right key to adjust " , True, (157,163,166))
    second_text = font1.render( "the direction, then press the forward or back ", True, (225, 166, 173))
    third_text = font1.render("button or the mouse button to move forward and back", True, (247, 249, 239))
    third_text_rect = third_text.get_rect()
    third_text_rect.topleft = [0,35]
    screen.blit(third_text, third_text_rect)
    second_text_rect = second_text.get_rect()
    second_text_rect.topleft = [0,20]
    screen.blit(second_text, second_text_rect)
    first_text_rect = first_text.get_rect()
    first_text_rect.topleft = [0,5]
    screen.blit(first_text, first_text_rect)

    grade_text = font1.render(str('grade point')+ ":"+str(grade_point), True, (0,0,0))
    textRect = grade_text.get_rect()
    textRect.topright = [635,5]
    screen.blit(grade_text, textRect)

    pygame.display.update()
